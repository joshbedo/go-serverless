package Config

import "gorm.io/gorm"

var DB *gorm.DB
